package com.cybertek.tests.day1_Navigation;

public class VrifyURLOfPracticeWeb {

    public static void main(String[] args) {
        /*
        1. go to cybertek practice website
                http://practice.cybertekschool.com/
        2. verify the URL
         */



    }
}
